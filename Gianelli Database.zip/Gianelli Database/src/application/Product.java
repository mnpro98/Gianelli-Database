package application;

import javafx.beans.property.SimpleStringProperty;

/**
 * This is the Product object.
 * @author mnpro
 *
 */
public class Product {

	private final SimpleStringProperty name;
	private final SimpleStringProperty id;
	private final SimpleStringProperty quantity;
	private final SimpleStringProperty price;
	private final SimpleStringProperty type;
	private final SimpleStringProperty image;

	/**
	 * This defines what the object will receive.
	 * @param fName
	 * @param lName
	 * @param idNum
	 * @param a
	 * @param e
	 * @param i
	 */
	public Product(String name, String id, String quantity, String price, String type, String image) {
		this.name = new SimpleStringProperty(name);
		this.id = new SimpleStringProperty(id);
		this.quantity = new SimpleStringProperty(quantity);
		this.price = new SimpleStringProperty(price);
		this.type = new SimpleStringProperty(type);
		this.image = new SimpleStringProperty(image);
	}
	//These are the setters and getters.

	public String getName() {
		return name.get();
	}

	public String getId() {
		return id.get();
	}

	public String getQuantity() {
		return quantity.get();
	}

	public String getPrice() {
		return price.get();
	}
	public String getType(){
		return type.get();
	}
	public String getImage(){
		return image.get();
	}

}
