package application;

import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;

/**
 * This is the main class.
 * @author mnpro
 * @version 1.00
 * @since 2016/08/01
 *
 */
public class Main extends Application {
	public static Parent root;
	public static Parent second;
	public static Parent third;
	public static Scene scene1;
	public static Scene scene2;
	public static Scene scene3;
	public static Stage mainStage;
	public static String selectedName;
	public static String selectedID;
	public static String selectedQuantity;
	public static String selectedPrice;
	public static String selectedType;
	public static String selectedImageURL;
	public static List<String[]> products = new ArrayList<String[]>();;
	public static ObservableList<Product> data = FXCollections.observableArrayList();

	/* (non-Javadoc)
	 * @see javafx.application.Application#start(javafx.stage.Stage)
	 */
	@Override
	public void start(Stage primaryStage) {
		try {
			root = FXMLLoader.load(getClass().getResource("/application/MainGUI.fxml"));
			second = FXMLLoader.load(getClass().getResource("/application/GUI1.fxml"));
			scene1 = new Scene(root);
			scene2 = new Scene(second);
			scene1.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("Gianelli Icon.png"))); //changes the program's icon
			primaryStage.setScene(scene1);
			primaryStage.setTitle("Gianelli Database"); //changes the title to "Gianelli Database"
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method makes the program run.
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
