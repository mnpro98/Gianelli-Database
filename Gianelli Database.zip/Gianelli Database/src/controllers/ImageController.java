package controllers;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.imageio.ImageIO;

import application.Main;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.SnapshotParameters;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;

/**
 * This class contains a window with the image inserted ready to save to the hard drive.
 * @author mnpro
 *
 */
public class ImageController implements Initializable {

	@FXML
	private AnchorPane datPane;
	@FXML
	private ImageView imageView1;
	@FXML
	private ImageView imageView2;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		FileChooser fileChooser = new FileChooser();
		Image image = new Image("file:" + Main.selectedImageURL);
		Image logo = new Image("file:Gianelli Logo2.png");
		imageView1.setImage(image);
		imageView2.setImage(logo);
		// reference:
		// http://stackoverflow.com/questions/32708250/how-snapshot-the-entire-scene-in-javafx
		WritableImage wi = datPane.snapshot(new SnapshotParameters(), null);

		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Image Files (*.png)", "*.png");
		fileChooser.getExtensionFilters().add(extFilter);
		File outFile = fileChooser.showSaveDialog(null);
		if (outFile != null) {
			try {
				ImageIO.write(SwingFXUtils.fromFXImage(wi, null), "png", outFile);
			} catch (IOException ex) {
				System.out.println(ex.getMessage());
			}

		}
	}

}
