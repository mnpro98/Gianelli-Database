package controllers;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import application.Main;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
 * This controller is for the interface to edit the selected product.
 * @author mnpro
 *
 */
public class EditController implements Initializable {
	@FXML
	private Button backButton;
	@FXML
	private Button insertButton;
	@FXML
	private Button imageButton;
	@FXML
	private ImageView imageView;
	@FXML
	private TextField name;
	@FXML
	private TextField id;
	@FXML
	private TextField quantity;
	@FXML
	private TextField price;
	@FXML
	private ChoiceBox<String> type;

	public ObjectInputStream loadFile;
	public ObjectOutputStream saveFile;
	private String fileLocation = System.getProperty("user.dir") + "/table.dat";
	public static String imagePath = Main.selectedImageURL;

	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try{
		type.setItems(FXCollections.observableArrayList("Elite", "Premium", "GIA"));
		name.setText(Main.selectedName);
		id.setText(Main.selectedID);
		quantity.setText(Main.selectedQuantity);
		price.setText(Main.selectedPrice);
		type.setValue(Main.selectedType);
		System.out.println(Main.selectedImageURL);
		Image image = new Image("file:" + Main.selectedImageURL);
		imageView.setImage(image);
		}catch (Exception e){

		}
		try {
			loadFile = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileLocation)));
			try {
				Main.products = (List<String[]>) loadFile.readObject();
				loadFile.close();
			} catch (ClassNotFoundException e) {
				Alert alert = new Alert(Alert.AlertType.ERROR);
				alert.setTitle("Information Dialog");
				alert.setHeaderText("Not found");
				alert.showAndWait();
			}
		} catch (FileNotFoundException e) {

		} catch (IOException e) {
		}
	}

	/**
	 * This method contains the actions of the "back" button. This returns the user to the main menu.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void goBack(ActionEvent event) throws IOException {
		boolean cancel = false;
			String[] aName = { Main.selectedName, Main.selectedID, Main.selectedQuantity, Main.selectedPrice, Main.selectedType, Main.selectedImageURL };
			if (cancel == false) {
				Main.products.add(aName);
				try {
					saveFile = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(fileLocation)));
					saveFile.writeObject(Main.products);
					saveFile.flush();
					saveFile.close();
					imagePath = null;
					Parent root = FXMLLoader.load(getClass().getResource("/application/MainGUI.fxml"));
					Scene scene1 = new Scene(root);
					application.Main.mainStage.setScene(scene1);
				} catch (FileNotFoundException e) {
					Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("File not found");
					alert.showAndWait();
				} catch (IOException e) {
					Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("IO Error");
					alert.showAndWait();
				}
			}
		}


	/**
	 * This method contains the actions of the "insert image" button. Brings the file insert menu and displays it in the imageView object.
	 * @param event
	 */
	@FXML
	public void imageInsert(ActionEvent event) {
		FileChooser chooser = new FileChooser();
		chooser.setTitle("Select a product image");
		chooser.getExtensionFilters().addAll(new ExtensionFilter("Image Files", "*.png", "*.jpg"));
		File imageFile = chooser.showOpenDialog(new Stage());

		if (imageFile != null) {
			try {
				imagePath = imageFile.toURI().toURL().toString();
				// System.out.println("file: " + imagePath);
				Image image = new Image(imagePath);
				imageView.setImage(image);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}

		} else {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("Please select a file. ");
			alert.showAndWait();
		}
		// File f = chooser.getSelectedFile();
		// String filename = f.getAbsolutePath();
		//
		// imageView.setImage(image);
	}

	/**
	 * This method saves the changes made.
	 * @param event
	 */
	@FXML
	public void insert(ActionEvent event) {
		boolean cancel = false;
		if (name.getText().isEmpty() || id.getText().isEmpty() || quantity.getText().isEmpty()
				|| price.getText().isEmpty()) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("All text fields must be filled!");
			alert.showAndWait();
		} else {
			String[] aName = { name.getText(), id.getText(), quantity.getText(), price.getText(), type.getValue().toString(), imagePath };
			for (int i = 0; i < Main.products.size(); i++) {
				if ("" + this.id.getText() == "" + Main.products.get(i)[2]) {
					Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("A product with that ID already exists");
					alert.showAndWait();
					cancel = true;
				}
			}
			if (cancel == false) {
				Main.products.add(aName);
				try {
					saveFile = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(fileLocation)));
					saveFile.writeObject(Main.products);
					saveFile.flush();
					saveFile.close();
					imagePath = null;
					Parent root = FXMLLoader.load(getClass().getResource("/application/MainGUI.fxml"));
					Scene scene1 = new Scene(root);
					application.Main.mainStage.setScene(scene1);
					Alert alert = new Alert(Alert.AlertType.INFORMATION);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("Save Successful!");
					alert.showAndWait();
				} catch (FileNotFoundException e) {
					Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("File not found");
					alert.showAndWait();
				} catch (IOException e) {
					Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("IO Error");
					alert.showAndWait();
				}
			}
		}
	}

}
