package controllers;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import application.Main;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
 * This controller is for the add product interface.
 * @author mnpro
 *
 */
public class Controller1 implements Initializable {
	@FXML
	private Button backButton;
	@FXML
	private Button insertButton;
	@FXML
	private Button imageButton;
	@FXML
	private ImageView imageView;
	@FXML
	private ImageView imageView2;
	@FXML
	private TextField name;
	@FXML
	private TextField id;
	@FXML
	private TextField quantity;
	@FXML
	private TextField price;
	@FXML
	private ChoiceBox<String> type;
	@FXML
	private Canvas canvas;

	public ObjectInputStream loadFile;
	public ObjectOutputStream saveFile;
	private String fileLocation = System.getProperty("user.dir") + "/table.dat";
	public static String imagePath;
	private Parent root;
	private Scene scene5;

	static GraphicsContext gr;
	//reference: http://docs.oracle.com/javafx/2/image_ops/jfxpub-image_ops.htm


	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			loadFile = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileLocation)));
			try {
				Main.products = (List<String[]>) loadFile.readObject();
				loadFile.close();
			} catch (ClassNotFoundException e) {
				// statusLabel.setText("Not found");
				Alert alert = new Alert(Alert.AlertType.ERROR);
				alert.setTitle("Information Dialog");
				alert.setHeaderText("Not found");
				alert.showAndWait();
			}
		} catch (FileNotFoundException e) {

		} catch (IOException e) {
		}
		final ContextMenu contextMenu = new ContextMenu();
		MenuItem save = new MenuItem("Save image to file");
		contextMenu.getItems().addAll(save);
		save.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent event){
				try {
					root = FXMLLoader.load(getClass().getResource("/application/ImageGUI.fxml"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				scene5 = new Scene(root);
			}
		});
		imageView.setOnMousePressed(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event){
				if (event.isSecondaryButtonDown()){
					contextMenu.show(imageView, event.getScreenX(), event.getScreenY());
				}
			}
		});
		type.setItems(FXCollections.observableArrayList("Elite", "Premium", "GIA"));
	}

	/**
	 * This method makes the button return the user to the main menu.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void goBack(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/application/MainGUI.fxml"));
		Scene scene1 = new Scene(root);
		application.Main.mainStage.setScene(scene1);
	}

	/**
	 * This defines the actions of the button to insert an image.
	 * @param event
	 */
	@FXML
	public void imageInsert(ActionEvent event) {
		FileChooser chooser = new FileChooser(); //74
		chooser.setTitle("Select a product image");
		chooser.getExtensionFilters().addAll(new ExtensionFilter("Image Files", "*.png", "*.jpg"));
		File imageFile = chooser.showOpenDialog(new Stage());

		if (imageFile != null) {
			try {
				Image logo = new Image(getClass().getResourceAsStream("Gianelli Logo2.png"));
				imagePath = imageFile.toURI().toURL().toString();
				Image image = new Image(imagePath);

				imagePath = imageFile.getAbsolutePath();
				 imageView.setImage(image);
				 imageView2.setImage(logo);
				 Main.selectedImageURL = imagePath;
				 System.out.print(imagePath);

			} catch (MalformedURLException e) {
				e.printStackTrace();
			}

		} else {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("Please select a file. ");
			alert.showAndWait();
		}

	}

	/**
	 * This method creates an instance of the object Product and returns the user to the main menu.
	 * @param event
	 */
	@FXML
	public void insert(ActionEvent event) {
		boolean cancel = false;
		if (name.getText().isEmpty() || id.getText().isEmpty() || quantity.getText().isEmpty()
				|| price.getText().isEmpty()) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("All text fields must be filled!");
			alert.showAndWait();
		} else {
			String[] aName = { name.getText(), id.getText(), quantity.getText(), price.getText(), type.getValue().toString(), imagePath };
			for (int i = 0; i < Main.products.size(); i++) {
				if ("" + this.id.getText() == "" + Main.products.get(i)[2]) {
					Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("A product with that ID already exists");
					alert.showAndWait();
					cancel = true;
				}
			}
			if (!cancel) {
				Main.products.add(aName);
				try {
					saveFile = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(fileLocation)));
					saveFile.writeObject(Main.products);
					saveFile.flush();
					saveFile.close();
					name.setText("");
					id.setText("");
					quantity.setText("");
					price.setText("");
					type.setValue("");
					imageView.setImage(null);
					imageView2.setImage(null);
					Parent root = FXMLLoader.load(getClass().getResource("/application/MainGUI.fxml"));
					Scene scene1 = new Scene(root);
					application.Main.mainStage.setScene(scene1);
					Alert alert = new Alert(Alert.AlertType.INFORMATION);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("Save Successful!");
					alert.showAndWait();
				} catch (FileNotFoundException e) {
					Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("File not found");
					alert.showAndWait();
				} catch (IOException e) {
					Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setTitle("Information Dialog");
					alert.setHeaderText("IO Error");
					alert.showAndWait();
				}
			}
		}
	}

}
