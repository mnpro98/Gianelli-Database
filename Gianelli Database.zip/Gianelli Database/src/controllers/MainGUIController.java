package controllers;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import application.Main;
import application.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * This class is for the interface to add new products.
 * @author mnpro
 *
 */
public class MainGUIController implements Initializable {
	@FXML
	private Button toSecond;
	@FXML
	private Button testButton;
	@FXML
	private Button editButton;
	@FXML
	private Button removeButton;
	@FXML
	private Button blacklistButton;
	@FXML
	private Button toggleButton;
	@FXML
	public TableView<Product> tableView;
	@FXML
	public TableColumn<Product, String> nameColumn;
	@FXML
	public TableColumn<Product, String> idColumn;
	@FXML
	public TableColumn<Product, String> quantityColumn;
	@FXML
	public TableColumn<Product, String> priceColumn;
	@FXML
	public TableColumn<Product, String> typeColumn;
	@FXML
	private Button backButton;
	public ObjectInputStream loadFile;
	public ObjectOutputStream saveFile;
	private String fileLocation = System.getProperty("user.dir") + "/table.dat";
	private String language = "English";

	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			loadFile = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileLocation)));
			try {
				Main.products = (List<String[]>) loadFile.readObject();
				loadFile.close();
			} catch (ClassNotFoundException e) {

			}
		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		}
		nameColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("name"));
		idColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("id"));
		quantityColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("quantity"));
		priceColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("price"));
		typeColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("type"));
		tableView.setEditable(true);
		for (int i = 0; i < Main.products.size(); i++) {
			Main.data.add(new Product(Main.products.get(i)[0], Main.products.get(i)[1], Main.products.get(i)[2],
					Main.products.get(i)[3], Main.products.get(i)[4], Main.products.get(i)[5]));
		}
		tableView.setItems(Main.data);
		removeButton.setDisable(true);
		editButton.setDisable(true); // reference:
										// http://stackoverflow.com/questions/17871329/disabling-a-button-in-javafx
		tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> { // reference:
																												// http://stackoverflow.com/questions/26424769/javafx8-how-to-create-listener-for-selection-of-row-in-tableview
			if (newSelection != null) {
				editButton.setDisable(false);
				removeButton.setDisable(false);
			}
		});

	}

	/**
	 * Switches the window to Scene 2.
	 * @param event
	 */
	@FXML
	public void goToSecond(ActionEvent event) {
		application.Main.mainStage = (Stage) toSecond.getScene().getWindow();
		application.Main.mainStage.setScene(application.Main.scene2);
		tableView.getItems().clear();
	}

	/**
	 * This method is for testing.
	 * @param event
	 */
	@FXML
	public void testButtonPressed(ActionEvent event) {
		tableView.getItems().clear();
	}

	/**
	 * Switches to the interface to edit a product information.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void editButtonPressed(ActionEvent event) throws IOException {
		// reference:
		// http://stackoverflow.com/questions/17388866/getting-selected-item-from-a-javafx-tableview
		Product product = tableView.getSelectionModel().getSelectedItem();
		Main.selectedName = product.getName();
		Main.selectedID = product.getId();
		Main.selectedQuantity = product.getQuantity();
		Main.selectedPrice = product.getPrice();
		Main.selectedType = product.getType();
		Main.selectedImageURL = product.getImage();
		application.Main.mainStage = (Stage) editButton.getScene().getWindow();
		Parent third = FXMLLoader.load(getClass().getResource("/application/EditGUI.fxml"));
		Scene scene3 = new Scene(third);
		application.Main.mainStage.setScene(scene3);
		for (int i = 0; i < Main.products.size(); i++) {
			if (product.getId().equals(Main.products.get(i)[1])) {
				Main.products.remove(i);
			}
		}
		try {
			saveFile = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(fileLocation)));
			saveFile.writeObject(Main.products);
			saveFile.flush();
			saveFile.close();
		} catch (FileNotFoundException e) {
			// Controller1.statusLabel.setText("File not found!");
		} catch (IOException e) {
			// Controller1.statusLabel.setText("IO ERROR!");
		}
		// Controller1.statusLabel.setText("Deleting Successful!");
		tableView.getItems().clear();
	}

	/**
	 * Contains the actions of the button to remove a product.
	 * @param event
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	@FXML
	public void remove(ActionEvent event) throws IOException {
		Product product = tableView.getSelectionModel().getSelectedItem();
		for (int i = 0; i < Main.products.size(); i++) {
			if (product.getId().equals(Main.products.get(i)[1])) {
				Main.products.remove(i);
			}
		}
		try {
			saveFile = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(fileLocation)));
			saveFile.writeObject(Main.products);
			saveFile.flush();
			saveFile.close();
			Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("Delete Successful!");
			alert.showAndWait();

		} catch (FileNotFoundException e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("File not found");
			alert.showAndWait();
		} catch (IOException e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("IO Error");
			alert.showAndWait();
		}
		tableView.getItems().clear();
		for (int i = 0; i < Main.products.size(); i++) {
			Main.data.add(new Product(Main.products.get(i)[0], Main.products.get(i)[1], Main.products.get(i)[2],
					Main.products.get(i)[3], Main.products.get(i)[4], Main.products.get(i)[5]));
		}
		tableView.setItems(Main.data);
	}

	/**
	 * Contains the the actions of the button that takes you to the blacklist interface.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void toBlackList(ActionEvent event) throws IOException {
		Parent laal = FXMLLoader.load(getClass().getResource("/application/BlacklistGUI.fxml"));
		Scene scene239 = new Scene(laal);
		application.Main.mainStage = (Stage) blacklistButton.getScene().getWindow();
		application.Main.mainStage.setScene(scene239);
	}

	/**
	 * This contains the actions of the button that changes the language of the program.
	 * @param event
	 */
	@FXML
	public void changeLanguage(ActionEvent event) {
		if (language == "English") {
			language = "Spanish";
			toggleButton.setText("English");
			nameColumn.setText("Nombre");
			quantityColumn.setText("Cantidad");
			priceColumn.setText("Precio");
			typeColumn.setText("Tipo");
			blacklistButton.setText("Lista Negra");
			toSecond.setText("Insertar producto");
			editButton.setText("Editar producto");
			removeButton.setText("Eliminar producto");
		} else {
			language = "English";
			toggleButton.setText("Espa�ol");
			nameColumn.setText("Name");
			quantityColumn.setText("Quantity");
			priceColumn.setText("Price");
			typeColumn.setText("Type");
			blacklistButton.setText("Blacklist");
			toSecond.setText("Insert new product");
			editButton.setText("Edit product");
			removeButton.setText("Delete product");
		}
	}

}
