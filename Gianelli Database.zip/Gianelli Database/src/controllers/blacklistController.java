package controllers;

import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import application.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * This is the controller of the blacklist interface.
 * @author mnpro
 *
 */
public class blacklistController implements Initializable {

	@FXML
	public TableView<Product> tableView;
	@FXML
	public TableColumn<Product, String> nameColumn;
	@FXML
	public TableColumn<Product, String> idColumn;
	@FXML
	public TableColumn<Product, String> quantityColumn;
	@FXML
	public TableColumn<Product, String> priceColumn;
	@FXML
	public TableColumn<Product, String> typeColumn;
	@FXML
	private Button backButton;
	public static ObservableList<Product> blackList = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		nameColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("name"));
		idColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("id"));
		quantityColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("quantity"));
		priceColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("price"));
		typeColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("type"));
		tableView.setEditable(true);
		for (int i = 0; i < Main.products.size(); i++) {
			if(Main.products.get(i)[2].equals("0")){
			blackList.add(new Product(Main.products.get(i)[0], Main.products.get(i)[1], Main.products.get(i)[2],
					Main.products.get(i)[3], Main.products.get(i)[4], Main.products.get(i)[5]));
			}
		}
		tableView.getItems().clear();
		tableView.setItems(blackList);
	}
	/**
	 * This method makes the "back" button do its function.
	 * @param event
	 */
	@FXML
	public void backButtonPressed (ActionEvent event){
		application.Main.mainStage = (Stage) backButton.getScene().getWindow();
		application.Main.mainStage.setScene(Main.scene1);
	}

}
